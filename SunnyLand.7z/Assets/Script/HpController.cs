using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HpController : MonoBehaviour
{
    public int maxHealth = 3;
    public int getHealth { get { return currentHealth; } }
    public float timeInvincible = 2.0f;

    Animator animator;
    int currentHealth;
    bool isInvincible;
    float InvincibleTimer;
    
    // Start is called before the first frame update
    void Start()
    {
        currentHealth = maxHealth;
        animator = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if (isInvincible)
        {
            InvincibleTimer -= Time.deltaTime;
            if(InvincibleTimer < 0)
            {
                isInvincible = false;
                animator.SetBool("IsHurt", false);
                animator.SetBool("IsIdle", false);
            }
        }
    }

    public void ChangeHealth(int amount)
    {
        if (amount < 0)
        {
            if (isInvincible)
            {
                return;
            }

            isInvincible = true;
            InvincibleTimer = timeInvincible;
            animator.SetBool("IsHurt", true);
        }
        currentHealth = Mathf.Clamp(currentHealth + amount, 0, maxHealth);
        Debug.Log(currentHealth + "/" + maxHealth);
    }
}
