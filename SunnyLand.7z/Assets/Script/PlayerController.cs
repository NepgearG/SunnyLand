using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour
{
    //�ٶȣ���Ծ��
    public float speed;
    public float jumpForce;
    public LayerMask ground;


    Animator _animator;
    Rigidbody2D _rigidbody2D;
    Collider2D _collider2D;
    bool secondJump = true;
    float secondJumptimer;
    bool onGround;
    float horizontal;
    float vertical;

    void Start()
    {
        _rigidbody2D = GetComponent<Rigidbody2D>();
        _animator = GetComponent<Animator>();
        _collider2D = GetComponent<CircleCollider2D>();
    }

    private void Update()
    {
        horizontal  = Input.GetAxis("Horizontal");
        vertical = Input.GetAxis("Vertical");
        jump();
    }
    void FixedUpdate()
    {
        movement();
        SwitchAnimator();
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        onGround = false;
        if (collision.GetContact(0).normal.y > 0.5f && (collision.gameObject.CompareTag("Ground")))
        {
            onGround = true;
        }
    }

    void jump()
    {
        if (Input.GetButtonDown("Jump") && _collider2D.IsTouchingLayers(ground))
        {
            _rigidbody2D.velocity = new Vector2(_rigidbody2D.velocity.x, jumpForce * Time.deltaTime);
            _animator.SetBool("IsJump", true);
        }

    }

    //�ƶ����
    void movement()
    {
        
        float facedirection = Input.GetAxisRaw("Horizontal");
        //x���ƶ�
        if(horizontal != 0)
        {
            _rigidbody2D.velocity = new Vector2( horizontal * speed * Time.deltaTime, _rigidbody2D.velocity.y);
            _animator.SetBool("IsRunning", true);
        }
        //��
        _animator.SetBool("IsCrouch", false);
        if (vertical > 0 && onGround)
        {
            _rigidbody2D.velocity = new Vector2(_rigidbody2D.velocity.x,  jumpForce * Time.deltaTime);
            _animator.SetBool("IsJump", true);
            onGround = false;

        }
        else if (vertical <0 && onGround)
        {
            _animator.SetBool("IsCrouch", true);
        }

        if (_animator.GetBool("IsJump"))
        {
            secondJumptimer++;
        }

        //second jump
        if (vertical > 0 && !onGround && secondJump && secondJumptimer>20)
        {
            _rigidbody2D.velocity = new Vector2(_rigidbody2D.velocity.x, jumpForce * Time.deltaTime);
            _animator.SetBool("IsJump", true);
            secondJump = false;
        }

        if (_collider2D.IsTouchingLayers(ground))
        {
            secondJump = true;
            secondJumptimer = 0;
        }

        if (_rigidbody2D.velocity.x == 0)
        {
            _animator.SetBool("IsRunning", false);
            }

        if (facedirection != 0)
        {
            transform.localScale = new Vector3(facedirection, 1, 1);
        }
        
    }

    //�л�����
    void SwitchAnimator()
    {
        _animator.SetBool("IsIdle", false);
        if (_animator.GetBool("IsJump"))
        {
            if (_rigidbody2D.velocity.y < 0)
            {
                _animator.SetBool("IsJump", false);
                _animator.SetBool("IsFall", true);
            }
        }

        else if (_collider2D.IsTouchingLayers(ground))
        {
            _animator.SetBool("IsFall", false);
            _animator.SetBool("IsIdle", true);
        }
    }

}
